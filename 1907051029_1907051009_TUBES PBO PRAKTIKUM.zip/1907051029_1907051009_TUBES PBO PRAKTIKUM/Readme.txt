tombol Hapus Patokan Berada Pada NIK
tombol update Patokan berasa pada NIK ,Dan data  Yang bisa di Update Hanya Jabatan Status dan Notelpom